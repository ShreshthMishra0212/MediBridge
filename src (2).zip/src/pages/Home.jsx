import { Link } from "react-router-dom";
import Navbar from "../components/Navbar";
import FeatureCard from "../components/FeatureCard";

export default function Home() {
  return (
    <div className="min-h-screen overflow-hidden bg-slate-50">
      <Navbar />
      <main>
        <section className="relative overflow-hidden">
          <div className="absolute -left-32 top-20 h-72 w-72 rounded-full bg-teal-200/30 blur-3xl" />
          <div className="absolute -right-32 top-10 h-96 w-96 rounded-full bg-emerald-200/30 blur-3xl" />
          <div className="relative mx-auto grid min-h-[650px] max-w-7xl items-center gap-12 px-5 py-16 lg:grid-cols-2 lg:px-8 lg:py-20">
            <div>
              <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-teal-200 bg-white px-4 py-2 shadow-sm">
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-teal-100">✨</span>
                <span className="text-xs font-bold tracking-wide text-teal-700">SMARTER HEALTHCARE</span>
              </div>
              <h1 className="max-w-3xl text-5xl font-black leading-[1.05] tracking-tight text-slate-900 md:text-6xl lg:text-7xl">
                Connecting
                <span className="block bg-gradient-to-r from-teal-500 via-emerald-500 to-cyan-500 bg-clip-text text-transparent">
                  Patients & Doctors
                </span>
                through better data.
              </h1>
              <p className="mt-7 max-w-xl text-base leading-8 text-slate-500 md:text-lg">
                MediBridge helps patients understand their medicines and find suitable doctors,
                while giving doctors structured healthcare information.
              </p>
              <div className="mt-9 flex flex-col gap-4 sm:flex-row">
                <Link to="/patient" className="rounded-2xl bg-gradient-to-r from-teal-500 to-emerald-500 px-7 py-4 text-center text-sm font-black text-white shadow-xl">
                  👤 Patient Portal →
                </Link>
                <Link to="/doctor" className="rounded-2xl border border-slate-200 bg-white px-7 py-4 text-center text-sm font-black text-slate-700 shadow-lg">
                  🩺 Doctor Portal →
                </Link>
              </div>
            </div>
            <div className="hidden lg:block">
              <div className="rounded-[36px] border border-white bg-white/90 p-5 shadow-2xl">
                <div className="rounded-2xl bg-gradient-to-br from-slate-950 to-slate-800 p-6 text-white">
                  <p className="text-xs font-bold uppercase tracking-widest text-teal-300">Medicine Analysis</p>
                  <h2 className="mt-2 text-2xl font-black">Medicine Data</h2>
                  <div className="mt-6 grid grid-cols-2 gap-3">
                    <div className="rounded-xl bg-white/5 p-4"><p className="text-xs text-slate-400">MEDICINE</p><b>Paracetamol</b></div>
                    <div className="rounded-xl bg-white/5 p-4"><p className="text-xs text-slate-400">STRENGTH</p><b>650 mg</b></div>
                  </div>
                </div>
                <div className="mt-5 grid grid-cols-2 gap-3">
                  <div className="rounded-2xl border border-teal-100 bg-teal-50 p-5">👤<p className="mt-3 font-black">Patient</p></div>
                  <div className="rounded-2xl border border-blue-100 bg-blue-50 p-5">🩺<p className="mt-3 font-black">Doctor</p></div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="border-t border-slate-200 bg-white py-16">
          <div className="mx-auto max-w-7xl px-5 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-xs font-black uppercase tracking-[0.2em] text-teal-500">One Healthcare Platform</p>
              <h2 className="mt-3 text-3xl font-black md:text-4xl">Built for better healthcare communication</h2>
            </div>
            <div className="mt-12 grid gap-5 md:grid-cols-3">
              <FeatureCard icon="📷" title="Medicine OCR" text="Extract medicine information from images using OCR technology." />
              <FeatureCard icon="🤖" title="AI Appointment Assistant" text="Get general guidance about the appropriate medical specialist." />
              <FeatureCard icon="🩺" title="Doctor Recommendations" text="Find highly rated doctors according to specialist and location." />
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}