import { useParams } from "react-router-dom";
import PortalHeader from "../../components/PortalHeader";
import StatusBadge from "../../components/StatusBadge";

export default function AppointmentDetails() {
  const { appointmentId } = useParams();
  return <div className="min-h-screen bg-slate-50"><PortalHeader role="doctor"/><main className="mx-auto max-w-3xl px-5 py-12">
    <div className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm"><p className="text-xs font-bold text-blue-500">APPOINTMENT #{appointmentId}</p><h1 className="mt-3 text-3xl font-black">Patient Appointment</h1><div className="mt-7 space-y-4"><p><b>Patient:</b> Aarav Gupta</p><p><b>Specialist:</b> General Physician</p><p><b>Date:</b> 2026-08-25</p><p><b>Time:</b> 10:00 AM</p><StatusBadge status="Confirmed"/></div><div className="mt-8 flex gap-3"><button className="rounded-xl bg-emerald-500 px-5 py-3 font-bold text-white">Mark Completed</button><button className="rounded-xl bg-red-50 px-5 py-3 font-bold text-red-600">Cancel</button></div></div>
  </main></div>;
}