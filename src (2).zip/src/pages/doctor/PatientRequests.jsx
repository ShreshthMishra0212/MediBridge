import { Link } from "react-router-dom";
import PortalHeader from "../../components/PortalHeader";
import StatusBadge from "../../components/StatusBadge";

const requests = [
  { id:1, patientId:101, patient:"Aarav Gupta", reason:"Fever and weakness", date:"2026-08-25", time:"10:00 AM", status:"Pending" },
  { id:2, patientId:102, patient:"Riya Sharma", reason:"Skin rash", date:"2026-08-26", time:"12:00 PM", status:"Confirmed" }
];

export default function PatientRequests() {
  return <div className="min-h-screen bg-slate-50"><PortalHeader role="doctor" /><main className="mx-auto max-w-5xl px-5 py-12">
    <p className="text-xs font-bold uppercase tracking-widest text-blue-500">PATIENT REQUESTS</p><h1 className="mt-3 text-4xl font-black">Incoming requests</h1>
    <div className="mt-7 space-y-4">{requests.map(r=><div key={r.id} className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
      <div className="flex flex-wrap justify-between gap-3"><div><h2 className="text-xl font-black">{r.patient}</h2><p className="mt-1 text-sm text-slate-500">{r.reason}</p></div><StatusBadge status={r.status}/></div>
      <div className="mt-5 grid gap-3 md:grid-cols-2"><p><b>Date:</b> {r.date}</p><p><b>Time:</b> {r.time}</p></div>
      <Link to={`/doctor/patients/${r.patientId}`} className="mt-5 inline-block rounded-xl bg-slate-900 px-5 py-3 text-sm font-bold text-white">View Patient →</Link>
    </div>)}</div>
  </main></div>;
}