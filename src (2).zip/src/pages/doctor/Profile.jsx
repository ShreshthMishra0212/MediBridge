import { useState } from "react";
import PortalHeader from "../../components/PortalHeader";

export default function Profile() {
  const [saved, setSaved] = useState(false);
  const [profile, setProfile] = useState({ name:"Dr. Ankit Sharma", specialist:"General Physician", area:"Noida", experience:"12 Years", fee:"₹500" });
  const update = (key, value) => setProfile(p=>({...p,[key]:value}));
  return (
    <div className="min-h-screen bg-slate-50"><PortalHeader role="doctor" /><main className="mx-auto max-w-3xl px-5 py-12">
      <p className="text-xs font-bold uppercase tracking-widest text-blue-500">DOCTOR PROFILE</p><h1 className="mt-3 text-4xl font-black">Professional Profile</h1>
      <div className="mt-8 space-y-5 rounded-3xl border border-slate-200 bg-white p-7 shadow-sm">
        {Object.entries(profile).map(([key,value])=><label key={key} className="block text-sm font-bold capitalize">{key}<input value={value} onChange={e=>update(key,e.target.value)} className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 font-normal" /></label>)}
        <button onClick={()=>setSaved(true)} className="rounded-xl bg-teal-500 px-6 py-3 font-bold text-white">Save Profile</button>
        {saved && <p className="text-sm font-bold text-emerald-600">✓ Profile saved locally.</p>}
      </div>
    </main></div>
  );
}