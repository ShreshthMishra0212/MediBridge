import { Link, useParams } from "react-router-dom";
import PortalHeader from "../../components/PortalHeader";

export default function PatientDetails() {
  const { patientId } = useParams();
  const patient = { id:patientId, name:"Aarav Gupta", age:22, bloodGroup:"B+", concern:"Fever and weakness", medicines:["Paracetamol 650 mg"] };
  return <div className="min-h-screen bg-slate-50"><PortalHeader role="doctor"/><main className="mx-auto max-w-4xl px-5 py-12">
    <p className="text-xs font-bold uppercase tracking-widest text-blue-500">PATIENT DETAILS</p><h1 className="mt-3 text-4xl font-black">{patient.name}</h1>
    <div className="mt-8 grid gap-4 md:grid-cols-3"><Info label="Age" value={patient.age}/><Info label="Blood Group" value={patient.bloodGroup}/><Info label="Patient ID" value={patient.id}/></div>
    <div className="mt-6 rounded-3xl border border-slate-200 bg-white p-7"><h2 className="text-xl font-black">Current Concern</h2><p className="mt-3 text-slate-600">{patient.concern}</p><h2 className="mt-7 text-xl font-black">Known Medicines</h2><ul className="mt-3 list-disc pl-5 text-slate-600">{patient.medicines.map(x=><li key={x}>{x}</li>)}</ul><Link to="/doctor/prescriptions" className="mt-7 inline-block rounded-xl bg-teal-500 px-6 py-3 font-bold text-white">Create Prescription →</Link></div>
  </main></div>;
}
function Info({label,value}){return <div className="rounded-2xl bg-white p-5 shadow-sm"><p className="text-xs text-slate-400">{label}</p><p className="mt-2 font-black">{value}</p></div>}