import { Link } from "react-router-dom";
import PortalHeader from "../../components/PortalHeader";

export default function Dashboard() {
  const cards = [
    ["/doctor/requests", "👥", "Patient Requests", "Review incoming appointment requests."],
    ["/doctor/profile", "🩺", "My Profile", "Manage specialist, area and professional details."],
    ["/doctor/prescriptions", "💊", "Prescriptions", "Create and manage patient prescriptions."],
  ];
  return (
    <div className="min-h-screen bg-slate-50">
      <PortalHeader role="doctor" />
      <main className="mx-auto max-w-7xl px-5 py-12">
        <span className="rounded-full bg-blue-50 px-3 py-2 text-xs font-bold text-blue-600">DOCTOR PORTAL</span>
        <h1 className="mt-5 text-4xl font-black md:text-5xl">Doctor Dashboard</h1>
        <p className="mt-4 max-w-2xl text-slate-500">Access patient requests, appointments, prescriptions and your professional profile.</p>
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {cards.map(([to,icon,title,text]) => <Link key={to} to={to} className="rounded-3xl border border-slate-200 bg-white p-7 shadow-sm hover:-translate-y-2 hover:shadow-xl"><div className="text-3xl">{icon}</div><h2 className="mt-5 text-xl font-black">{title}</h2><p className="mt-3 text-sm text-slate-500">{text}</p><span className="mt-5 inline-block text-sm font-bold text-teal-600">Open →</span></Link>)}
        </div>
      </main>
    </div>
  );
}