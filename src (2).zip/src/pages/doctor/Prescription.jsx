import { useState } from "react";
import PortalHeader from "../../components/PortalHeader";

export default function Prescription() {
  const [saved, setSaved] = useState(false);
  const [form, setForm] = useState({ patient:"Aarav Gupta", diagnosis:"", medicines:"", instructions:"" });
  const change = (k,v)=>setForm(p=>({...p,[k]:v}));
  return <div className="min-h-screen bg-slate-50"><PortalHeader role="doctor"/><main className="mx-auto max-w-3xl px-5 py-12">
    <p className="text-xs font-bold uppercase tracking-widest text-violet-500">DOCTOR PRESCRIPTION</p><h1 className="mt-3 text-4xl font-black">Create Prescription</h1>
    <div className="mt-8 space-y-5 rounded-3xl border border-slate-200 bg-white p-7 shadow-sm">
      {Object.entries(form).map(([k,v])=><label key={k} className="block text-sm font-bold capitalize">{k}<textarea rows={k==="medicines"||k==="instructions"?4:1} value={v} onChange={e=>change(k,e.target.value)} className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 font-normal"/></label>)}
      <button onClick={()=>setSaved(true)} className="rounded-xl bg-gradient-to-r from-teal-500 to-emerald-500 px-6 py-3 font-bold text-white">Save Prescription</button>
      {saved && <p className="text-sm font-bold text-emerald-600">✓ Prescription saved.</p>}
    </div>
  </main></div>;
}