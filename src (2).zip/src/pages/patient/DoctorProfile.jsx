import { Link, useParams } from "react-router-dom";
import PortalHeader from "../../components/PortalHeader";
import { doctors } from "../../utils/doctors";

export default function DoctorProfile() {
  const { doctorId } = useParams();
  const doctor = doctors.find(d => d.id === Number(doctorId));
  if (!doctor) return <NotFound />;
  return (
    <div className="min-h-screen bg-slate-50">
      <PortalHeader />
      <main className="mx-auto max-w-4xl px-5 py-12">
        <div className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
          <div className="flex flex-col gap-6 md:flex-row md:items-center">
            <div className="flex h-24 w-24 items-center justify-center rounded-3xl bg-blue-50 text-5xl">🩺</div>
            <div><p className="text-sm font-bold text-teal-600">{doctor.specialist}</p><h1 className="mt-2 text-4xl font-black">{doctor.name}</h1><p className="mt-2 text-slate-500">{doctor.area} · {doctor.experience} experience</p></div>
          </div>
          <div className="mt-8 grid gap-4 md:grid-cols-3">
            <Info label="Rating" value={`⭐ ${doctor.rating}`} />
            <Info label="Experience" value={doctor.experience} />
            <Info label="Consultation Fee" value={doctor.fee} />
          </div>
          <Link to="/patient/book-appointment" className="mt-8 inline-block rounded-xl bg-teal-500 px-6 py-3 font-bold text-white">Book Appointment →</Link>
        </div>
      </main>
    </div>
  );
}
function Info({label,value}) { return <div className="rounded-2xl bg-slate-50 p-5"><p className="text-xs text-slate-400">{label}</p><p className="mt-2 font-black">{value}</p></div>; }
function NotFound() { return <div className="p-10">Doctor not found.</div>; }