import { Link, useParams } from "react-router-dom";
import PortalHeader from "../../components/PortalHeader";
import StatusBadge from "../../components/StatusBadge";
import { useApp } from "../../context/AppContext";

export default function AppointmentDetails() {
  const { appointmentId } = useParams();
  const { appointments, updateAppointment } = useApp();
  const appointment = appointments.find(a => a.id === Number(appointmentId));
  if (!appointment) return <div className="p-10">Appointment not found.</div>;

  return (
    <div className="min-h-screen bg-slate-50">
      <PortalHeader />
      <main className="mx-auto max-w-3xl px-5 py-12">
        <div className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
          <div className="flex justify-between gap-4"><div><p className="text-xs font-bold text-teal-500">APPOINTMENT DETAILS</p><h1 className="mt-3 text-3xl font-black">{appointment.doctorName}</h1></div><StatusBadge status={appointment.status} /></div>
          <div className="mt-7 space-y-4">
            <p><b>Specialist:</b> {appointment.specialist}</p><p><b>Area:</b> {appointment.area}</p><p><b>Rating:</b> ⭐ {appointment.rating}</p><p><b>Date:</b> {appointment.date}</p><p><b>Time:</b> {appointment.time}</p>
          </div>
          {appointment.status !== "Cancelled" && <button onClick={()=>updateAppointment(appointment.id,{status:"Cancelled"})} className="mt-8 rounded-xl bg-red-50 px-5 py-3 text-sm font-bold text-red-600">Cancel Appointment</button>}
          <Link to="/patient/appointments" className="ml-3 inline-block rounded-xl bg-slate-900 px-5 py-3 text-sm font-bold text-white">Back</Link>
        </div>
      </main>
    </div>
  );
}