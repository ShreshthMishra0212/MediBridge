import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import PortalHeader from "../../components/PortalHeader";
import DoctorCard from "../../components/DoctorCard";
import { doctors, areas, specialists } from "../../utils/doctors";
import { localSpecialistRecommendation } from "../../utils/aiRules";
import useKokoroTTS from "../../hooks/useKokoroTTS";
import { useApp } from "../../context/AppContext";

export default function BookAppointment() {
  const [symptoms, setSymptoms] = useState("");
  const [specialist, setSpecialist] = useState("");
  const [area, setArea] = useState("");
  const [selectedDoctor, setSelectedDoctor] = useState(null);
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [aiLoading, setAiLoading] = useState(false);
  const [aiAdvice, setAiAdvice] = useState("");
  const { speak, stop, loading, speaking } = useKokoroTTS();
  const { addAppointment } = useApp();

  const recommendedDoctors = useMemo(
    () =>
      doctors
        .filter((d) => (!specialist || d.specialist === specialist) && (!area || d.area === area))
        .sort((a, b) => b.rating - a.rating),
    [specialist, area]
  );

  const askAI = async () => {
    if (!symptoms.trim()) return alert("Please describe your symptoms first.");
    setAiLoading(true);
    stop();
    await new Promise((r) => setTimeout(r, 700));
    const result = localSpecialistRecommendation(symptoms);
    setSpecialist(result.specialist);
    setAiAdvice(result.advice);
    setSelectedDoctor(null);
    setAiLoading(false);
  };

  const book = (e) => {
    e.preventDefault();
    if (!selectedDoctor || !date || !time) return alert("Please select doctor, date and time.");
    addAppointment({
      doctorId: selectedDoctor.id,
      doctorName: selectedDoctor.name,
      specialist: selectedDoctor.specialist,
      area: selectedDoctor.area,
      rating: selectedDoctor.rating,
      date,
      time,
      status: "Confirmed",
    });
    window.location.href = "/patient/appointments";
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <PortalHeader />
      <main className="mx-auto max-w-7xl px-5 py-12 lg:px-8">
        <span className="rounded-full bg-blue-50 px-3 py-2 text-xs font-bold text-blue-600">AI APPOINTMENT ASSISTANT</span>
        <h1 className="mt-5 text-4xl font-black md:text-5xl">Find the right doctor</h1>
        <p className="mt-3 max-w-2xl text-slate-500">Describe symptoms, get general specialist guidance, then choose a highly rated doctor by area.</p>

        <section className="mt-8 rounded-[28px] bg-gradient-to-br from-slate-950 via-slate-900 to-teal-950 p-7 text-white shadow-xl">
          <div className="flex items-center gap-4">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-teal-400/10 text-3xl">🤖</div>
            <div>
              <p className="text-xs font-bold uppercase tracking-widest text-teal-300">MediBridge AI</p>
              <h2 className="mt-1 text-2xl font-black">Which specialist do I need?</h2>
            </div>
          </div>
          <textarea value={symptoms} onChange={(e) => setSymptoms(e.target.value)} rows={4}
            placeholder="Describe your symptoms or health concern..."
            className="mt-6 w-full resize-none rounded-2xl border border-white/10 bg-white/5 px-5 py-4 text-sm text-white outline-none placeholder:text-slate-500 focus:border-teal-400" />
          <button onClick={askAI} disabled={aiLoading}
            className="mt-4 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-500 px-7 py-3.5 text-sm font-black disabled:opacity-60">
            {aiLoading ? "🤖 AI is analyzing..." : "Ask AI Assistant →"}
          </button>

          {aiAdvice && (
            <div className="mt-6 rounded-2xl border border-teal-400/20 bg-teal-400/10 p-6">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="text-xs font-bold uppercase tracking-widest text-teal-300">AI Recommendation</p>
                  <h3 className="mt-2 text-xl font-black">{specialist}</h3>
                </div>
                {!speaking ? (
                  <button onClick={() => speak(`The recommended specialist is ${specialist}. ${aiAdvice}`)} disabled={loading} className="rounded-xl bg-white/10 px-4 py-2 text-xs font-bold">
                    {loading ? "⏳ Loading voice..." : "🔊 Read Aloud"}
                  </button>
                ) : (
                  <button onClick={stop} className="rounded-xl bg-red-500/20 px-4 py-2 text-xs font-bold text-red-200">⏹ Stop</button>
                )}
              </div>
              <p className="mt-4 text-sm leading-7 text-slate-300">{aiAdvice}</p>
            </div>
          )}
        </section>

        <section className="mt-8 rounded-3xl border border-slate-200 bg-white p-7 shadow-sm">
          <div className="grid gap-4 md:grid-cols-2">
            <label className="text-sm font-bold">Area
              <select value={area} onChange={(e) => { setArea(e.target.value); setSelectedDoctor(null); }} className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3">
                <option value="">All areas</option>
                {areas.map((x) => <option key={x}>{x}</option>)}
              </select>
            </label>
            <label className="text-sm font-bold">Specialist
              <select value={specialist} onChange={(e) => { setSpecialist(e.target.value); setSelectedDoctor(null); }} className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3">
                <option value="">Any specialist</option>
                {specialists.map((x) => <option key={x}>{x}</option>)}
              </select>
            </label>
          </div>
        </section>

        <section className="mt-8">
          <div className="flex items-center justify-between">
            <div><p className="text-xs font-bold uppercase tracking-widest text-teal-500">DOCTOR RECOMMENDATIONS</p><h2 className="mt-2 text-2xl font-black">Highly rated doctors</h2></div>
            <span className="rounded-full bg-amber-50 px-4 py-2 text-xs font-bold text-amber-600">⭐ Rating Wise</span>
          </div>
          <div className="mt-6 grid gap-5 md:grid-cols-2">
            {recommendedDoctors.map((doctor) => (
              <DoctorCard key={doctor.id} doctor={doctor} selected={selectedDoctor?.id === doctor.id} onSelect={setSelectedDoctor} />
            ))}
          </div>
        </section>

        <form onSubmit={book} className="mt-8 rounded-3xl border border-slate-200 bg-white p-7 shadow-sm">
          <p className="text-xs font-bold uppercase tracking-widest text-blue-500">BOOKING DETAILS</p>
          <h2 className="mt-2 text-2xl font-black">Select appointment time</h2>
          <div className="mt-6 grid gap-5 md:grid-cols-3">
            <label className="text-sm font-bold">Doctor
              <select value={selectedDoctor?.id || ""} onChange={(e) => setSelectedDoctor(doctors.find((d) => d.id === Number(e.target.value)) || null)} className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3">
                <option value="">Select doctor</option>
                {recommendedDoctors.map((d) => <option key={d.id} value={d.id}>{d.name} — ⭐ {d.rating}</option>)}
              </select>
            </label>
            <label className="text-sm font-bold">Date
              <input type="date" value={date} min={new Date().toISOString().split("T")[0]} onChange={(e) => setDate(e.target.value)} className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3" />
            </label>
            <label className="text-sm font-bold">Time
              <select value={time} onChange={(e) => setTime(e.target.value)} className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3">
                <option value="">Choose time</option>
                {["10:00 AM","11:00 AM","12:00 PM","2:00 PM","4:00 PM","6:00 PM"].map((x) => <option key={x}>{x}</option>)}
              </select>
            </label>
          </div>
          <button className="mt-7 w-full rounded-xl bg-gradient-to-r from-teal-500 to-emerald-500 py-4 text-sm font-black text-white">Confirm Appointment →</button>
        </form>

        <div className="mt-8 rounded-2xl border border-amber-200 bg-amber-50 p-5 text-xs leading-6 text-amber-700">
          ⚠️ <b>Important:</b> The AI assistant provides general informational guidance only. It does not diagnose medical conditions or replace a qualified healthcare professional.
        </div>
        <Link to="/patient" className="mt-6 inline-block text-sm font-bold text-teal-600">← Back to dashboard</Link>
      </main>
    </div>
  );
}