import { useEffect, useRef, useState } from "react";

import PortalHeader from "../../components/PortalHeader";
import useKokoroTTS from "../../hooks/useKokoroTTS";
import { extractMedicine } from "../../services/ocrApi";


export default function MedicineVerification() {
  const [image, setImage] = useState(null);
  const [file, setFile] = useState(null);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const inputRef = useRef(null);

  const {
    speak,
    stop,
    loading: ttsLoading,
    speaking,
  } = useKokoroTTS();

  const chooseImage = (e) => {
    const selected = e.target.files?.[0];

    if (!selected) return;

    if (image) {
      URL.revokeObjectURL(image);
    }

    stop();

    setFile(selected);
    setImage(URL.createObjectURL(selected));
    setResult(null);
  };

  const analyse = async () => {
    if (!file) {
      alert("Please select a medicine image first.");
      return;
    }

    setLoading(true);
    setResult(null);
    stop();

    try {
      const data = await extractMedicine(file);

      const salts = data?.salts;

      setResult({
        medicine:
          salts?.medicine ||
          salts?.name ||
          data?.medicine ||
          data?.name ||
          "No medicine detected",

        salt:
          salts?.salt ||
          salts?.composition ||
          data?.salt ||
          data?.composition ||
          "No salt detected",
      });
    } catch (error) {
      setResult({
        error:
          error.response?.data?.error ||
          error.response?.data?.message ||
          "Could not connect to the OCR backend. Make sure Flask is running on port 5000.",
      });
    } finally {
      setLoading(false);
    }
  };

  const remove = () => {
    stop();

    if (image) {
      URL.revokeObjectURL(image);
    }

    setImage(null);
    setFile(null);
    setResult(null);

    if (inputRef.current) {
      inputRef.current.value = "";
    }
  };

  useEffect(() => {
    return () => {
      stop();

      if (image) {
        URL.revokeObjectURL(image);
      }
    };
  }, []);

  return (
    <div className="min-h-screen bg-slate-50">
      <PortalHeader />

      <main className="mx-auto max-w-6xl px-5 py-12">
        {/* Page Header */}
        <span className="rounded-full bg-teal-50 px-3 py-2 text-xs font-bold text-teal-600">
          MEDICINE OCR
        </span>

        <h1 className="mt-5 text-4xl font-black">
          Scan Medicine
        </h1>

        <p className="mt-3 text-slate-500">
          Upload a clear medicine image and MediBridge will extract medicine
          information and read it aloud.
        </p>

        {/* Main Card */}
        <section className="mt-8 rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
          {!image ? (
            /* Upload Section */
            <label className="flex cursor-pointer flex-col items-center justify-center rounded-3xl border-2 border-dashed border-slate-300 bg-slate-50 px-6 py-16 text-center transition hover:border-teal-400 hover:bg-teal-50/30">
              
              {/* Medicine Image */}
              <div className="flex h-28 w-28 items-center justify-center overflow-hidden rounded-3xl shadow-sm">
                <img
                  src="/medicine.png"
                  alt="Medicine"
                  className="h-full w-full object-cover"
                />
              </div>

              <h2 className="mt-6 text-xl font-black text-slate-900">
                Upload Medicine Image
              </h2>

              <p className="mt-2 text-sm text-slate-400">
                PNG, JPG or JPEG
              </p>

              <span className="mt-6 rounded-xl bg-slate-900 px-7 py-3 text-sm font-bold text-white transition hover:bg-slate-800">
                Choose Image
              </span>

              <input
                ref={inputRef}
                type="file"
                accept="image/png,image/jpeg,image/jpg"
                onChange={chooseImage}
                className="hidden"
              />
            </label>
          ) : (
            /* Uploaded Image Section */
            <div className="text-center">
              <img
                src={image}
                alt="Uploaded medicine"
                className="mx-auto max-h-80 rounded-2xl object-contain shadow-lg"
              />

              <div className="mt-7 flex justify-center gap-3">
                <button
                  onClick={analyse}
                  disabled={loading}
                  className="rounded-xl bg-teal-500 px-7 py-3 font-bold text-white transition hover:bg-teal-600 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {loading ? "Reading Image..." : "Generate Text →"}
                </button>

                <button
                  onClick={remove}
                  disabled={loading}
                  className="rounded-xl bg-slate-100 px-7 py-3 font-bold text-slate-600 transition hover:bg-slate-200 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  Remove Image
                </button>
              </div>
            </div>
          )}

          {/* OCR Result */}
          {result && (
            <div className="mt-8 rounded-3xl bg-slate-950 p-7 text-white">
              {result.error ? (
                <>
                  <p className="font-bold text-red-300">
                    OCR Error
                  </p>

                  <p className="mt-2 text-sm text-red-200">
                    {result.error}
                  </p>
                </>
              ) : (
                <>
                  {/* Result Header */}
                  <div className="flex flex-wrap justify-between gap-3">
                    <div>
                      <p className="text-xs font-bold uppercase tracking-widest text-teal-300">
                        OCR RESULT
                      </p>

                      <h2 className="mt-2 text-xl font-black">
                        Medicine Information
                      </h2>
                    </div>

                    {/* Text To Speech */}
                    {!speaking ? (
                      <button
                        onClick={() =>
                          speak(
                            `The medicine detected is ${result.medicine}. The salt composition is ${result.salt}.`
                          )
                        }
                        disabled={ttsLoading}
                        className="rounded-xl bg-white/10 px-4 py-2 text-xs font-bold transition hover:bg-white/20 disabled:cursor-not-allowed disabled:opacity-50"
                      >
                        {ttsLoading
                          ? "⏳ Loading voice..."
                          : "🔊 Read Aloud"}
                      </button>
                    ) : (
                      <button
                        onClick={stop}
                        className="rounded-xl bg-red-500/20 px-4 py-2 text-xs font-bold text-red-200 transition hover:bg-red-500/30"
                      >
                        ⏹ Stop
                      </button>
                    )}
                  </div>

                  {/* Medicine Information */}
                  <div className="mt-5 grid gap-4 md:grid-cols-2">
                    {/* Medicine */}
                    <div className="rounded-2xl bg-white/5 p-5">
                      <p className="text-xs text-slate-400">
                        MEDICINE
                      </p>

                      <p className="mt-2 text-xl font-black">
                        {result.medicine}
                      </p>
                    </div>

                    {/* Salt */}
                    <div className="rounded-2xl bg-white/5 p-5">
                      <p className="text-xs text-slate-400">
                        SALT
                      </p>

                      <p className="mt-2 text-xl font-black">
                        {result.salt}
                      </p>
                    </div>
                  </div>
                </>
              )}
            </div>
          )}
        </section>
      </main>
    </div>
  );
}