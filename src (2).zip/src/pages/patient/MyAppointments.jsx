import { Link } from "react-router-dom";
import PortalHeader from "../../components/PortalHeader";
import StatusBadge from "../../components/StatusBadge";
import { useApp } from "../../context/AppContext";

export default function MyAppointments() {
  const { appointments } = useApp();
  return (
    <div className="min-h-screen bg-slate-50">
      <PortalHeader />
      <main className="mx-auto max-w-5xl px-5 py-12">
        <p className="text-xs font-bold uppercase tracking-widest text-teal-500">MY APPOINTMENTS</p>
        <h1 className="mt-3 text-4xl font-black">Appointments</h1>
        <div className="mt-7 space-y-4">
          {appointments.map(a => (
            <div key={a.id} className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div><h2 className="text-xl font-black">{a.doctorName}</h2><p className="mt-1 text-sm text-teal-600">{a.specialist}</p></div>
                <StatusBadge status={a.status} />
              </div>
              <div className="mt-5 grid gap-3 md:grid-cols-4">
                <Info label="Date" value={a.date} /><Info label="Time" value={a.time} /><Info label="Area" value={a.area} /><Info label="Rating" value={`⭐ ${a.rating}`} />
              </div>
              <Link to={`/patient/appointments/${a.id}`} className="mt-5 inline-block text-sm font-bold text-teal-600">View details →</Link>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
function Info({label,value}) { return <div className="rounded-xl bg-slate-50 p-3"><p className="text-[10px] text-slate-400">{label}</p><p className="mt-1 text-sm font-bold">{value}</p></div>; }