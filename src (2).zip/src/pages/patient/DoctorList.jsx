import { useMemo, useState } from "react";
import PortalHeader from "../../components/PortalHeader";
import DoctorCard from "../../components/DoctorCard";
import { doctors, areas, specialists } from "../../utils/doctors";

export default function DoctorList() {
  const [area, setArea] = useState("");
  const [specialist, setSpecialist] = useState("");
  const list = useMemo(() => doctors.filter(d => (!area || d.area === area) && (!specialist || d.specialist === specialist)).sort((a,b)=>b.rating-a.rating), [area, specialist]);

  return (
    <div className="min-h-screen bg-slate-50">
      <PortalHeader />
      <main className="mx-auto max-w-7xl px-5 py-12">
        <p className="text-xs font-bold uppercase tracking-widest text-teal-500">DOCTOR LIST</p>
        <h1 className="mt-3 text-4xl font-black">Find a doctor</h1>
        <div className="mt-7 grid gap-4 rounded-3xl border border-slate-200 bg-white p-6 md:grid-cols-2">
          <select value={area} onChange={e=>setArea(e.target.value)} className="rounded-xl border border-slate-200 px-4 py-3"><option value="">All areas</option>{areas.map(x=><option key={x}>{x}</option>)}</select>
          <select value={specialist} onChange={e=>setSpecialist(e.target.value)} className="rounded-xl border border-slate-200 px-4 py-3"><option value="">All specialists</option>{specialists.map(x=><option key={x}>{x}</option>)}</select>
        </div>
        <div className="mt-7 grid gap-5 md:grid-cols-2">{list.map(d=><DoctorCard key={d.id} doctor={d} onSelect={()=>{}} />)}</div>
      </main>
    </div>
  );
}