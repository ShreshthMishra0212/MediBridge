import { useState, useRef } from "react";
import axios from "axios";

import PortalHeader from "../../components/PortalHeader";
import EmptyState from "../../components/EmptyState";
import useKokoroTTS from "../../hooks/useKokoroTTS";

const BASE_URL = "http://192.168.9.23:5000";

export default function Prescription() {
  // =========================================================
  // STATE
  // =========================================================

  const [patientId, setPatientId] = useState("pa111");

  const [prescriptions, setPrescriptions] = useState([]);

  const [selectedFiles, setSelectedFiles] = useState([]);

  const [progress, setProgress] = useState(0);

  const [isUploading, setIsUploading] = useState(false);

  const [status, setStatus] = useState(null);

  const [response, setResponse] = useState(null);

  const [error, setError] = useState(null);

  // AI briefs for each prescription
  const [briefs, setBriefs] = useState({});

  const [briefingIndex, setBriefingIndex] = useState(null);

  const fileInputRef = useRef(null);

  // =========================================================
  // KOKORO TTS
  // =========================================================

  const {
    speak,
    stop,
    loading: ttsLoading,
    speaking,
  } = useKokoroTTS();

  // =========================================================
  // FILE SELECTION
  // =========================================================

  const handleFileChange = (event) => {
    const files = Array.from(event.target.files || []);

    if (files.length === 0) {
      return;
    }

    setError(null);
    setStatus(null);
    setResponse(null);

    const validFiles = files.filter((file) => {
      return (
        file.type === "application/pdf" ||
        file.type ===
          "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
      );
    });

    if (validFiles.length !== files.length) {
      setError("Only PDF and DOCX files are allowed.");
    }

    setSelectedFiles(validFiles);
  };

  // =========================================================
  // REMOVE SELECTED FILE
  // =========================================================

  const removeFile = (index) => {
    setSelectedFiles((previous) =>
      previous.filter((_, currentIndex) => currentIndex !== index)
    );
  };

  // =========================================================
  // UPLOAD PRESCRIPTION
  // =========================================================

  const handleUpload = async () => {
    if (!patientId.trim()) {
      setError("Please enter a patient ID.");
      return;
    }

    if (selectedFiles.length === 0) {
      setError("Please choose at least one prescription.");
      return;
    }

    setIsUploading(true);
    setError(null);
    setStatus(null);
    setResponse(null);
    setProgress(0);

    const formData = new FormData();

    selectedFiles.forEach((file) => {
      formData.append("files", file);
    });

    try {
      const uploadUrl =
        `${BASE_URL}/upload?fname=` +
        encodeURIComponent(patientId);

      console.log("Uploading prescription...");
      console.log("URL:", uploadUrl);
      console.log("Patient ID:", patientId);

      const res = await axios.post(
        uploadUrl,
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },

          onUploadProgress: (event) => {
            if (!event.total) {
              return;
            }

            const percentage = Math.round(
              (event.loaded / event.total) * 100
            );

            setProgress(percentage);
          },
        }
      );

      console.log("Upload response:", res.data);

      setProgress(100);

      setStatus({
        ok: true,
        code: res.status,
      });

      setResponse(res.data);

      // =====================================================
      // ADD FILES TO LOCAL PRESCRIPTION LIST
      // =====================================================

      const uploadedPrescriptions = selectedFiles.map((file) => ({
        id: `${Date.now()}-${file.name}-${Math.random()}`,
        name: file.name,
        date: new Date().toLocaleDateString(),
        file: file,
      }));

      setPrescriptions((previous) => [
        ...uploadedPrescriptions,
        ...previous,
      ]);

      setSelectedFiles([]);

      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    } catch (err) {
      console.error("Prescription upload error:", err);

      setProgress(0);

      if (err.response) {
        setStatus({
          ok: false,
          code: err.response.status,
        });

        setResponse(err.response.data);

        setError(
          err.response.data?.error ||
            err.response.data?.message ||
            `Upload failed with HTTP ${err.response.status}.`
        );
      } else if (err.request) {
        setError(
          "Could not connect to the MediBridge backend."
        );
      } else {
        setError(
          err.message ||
            "Prescription upload failed."
        );
      }
    } finally {
      setIsUploading(false);
    }
  };

  // =========================================================
  // AI BRIEF
  // =========================================================

  const generateBrief = async (prescription) => {
    const prescriptionId = prescription.id;

    stop();

    setBriefingIndex(prescriptionId);
    setError(null);

    try {
      console.log("====================================");
      console.log("AI BRIEF REQUEST");
      console.log("Endpoint:", `${BASE_URL}/brief_assist`);
      console.log("Patient ID:", patientId);
      console.log("Prescription:", prescription.name);
      console.log("====================================");

      // =====================================================
      // YOUR FLASK ENDPOINT IS GET
      //
      // Flask:
      //
      // @app.route("/brief_assist", methods=["GET"])
      //
      // So we use axios.get()
      // =====================================================

      const res = await axios.get(
        `${BASE_URL}/brief_assist`,
        {
          params: {
            fname: patientId,
          },

          timeout: 120000,
        }
      );

      console.log(
        "AI BRIEF STATUS:",
        res.status
      );

      console.log(
        "AI BRIEF RAW RESPONSE:",
        res.data
      );

      const responseData = res.data;

      // =====================================================
      // CHECK RESPONSE
      // =====================================================

      if (!responseData) {
        throw new Error(
          "AI server returned an empty response."
        );
      }

      // =====================================================
      // GET ACTUAL AI OBJECT
      // =====================================================

      /*
        Your backend returns something like:

        {
          status: "success",

          summary: {
            duration: "...",
            instruction: "...",
            medicines: [...],
            precaution: "...",
            purpose: "...",
            summary: "..."
          }
        }

        Therefore summary itself can be an object.
      */

      let aiData = responseData;

      if (
        responseData.summary &&
        typeof responseData.summary === "object" &&
        !Array.isArray(responseData.summary)
      ) {
        aiData = responseData.summary;
      }

      console.log(
        "EXTRACTED AI DATA:",
        aiData
      );

      // =====================================================
      // MEDICINES
      // =====================================================

      let medicines = [];

      if (Array.isArray(aiData.medicines)) {
        medicines = aiData.medicines.map(
          (medicine) => {
            if (
              typeof medicine === "string"
            ) {
              return {
                name: medicine,
                dosage: "See prescription",
                frequency: "See prescription",
              };
            }

            return {
              name:
                medicine?.name ||
                medicine?.medicine_name ||
                medicine?.medication ||
                "Unknown medicine",

              dosage:
                medicine?.dosage ||
                medicine?.dose ||
                "Not specified",

              frequency:
                medicine?.frequency ||
                medicine?.timing ||
                medicine?.schedule ||
                "Not specified",
            };
          }
        );
      } else if (
        typeof aiData.medicines === "string"
      ) {
        medicines = [
          {
            name: aiData.medicines,
            dosage: "See prescription",
            frequency: "See prescription",
          },
        ];
      }

      // =====================================================
      // DURATION
      // =====================================================

      let duration = "Not specified";

      if (
        typeof aiData.duration === "string"
      ) {
        duration = aiData.duration;
      } else if (
        aiData.duration !== undefined &&
        aiData.duration !== null
      ) {
        duration = JSON.stringify(
          aiData.duration
        );
      }

      // =====================================================
      // PURPOSE
      // =====================================================

      let purpose = "Not specified";

      if (
        typeof aiData.purpose === "string"
      ) {
        purpose = aiData.purpose;
      } else if (
        aiData.purpose !== undefined &&
        aiData.purpose !== null
      ) {
        purpose = JSON.stringify(
          aiData.purpose
        );
      }

      // =====================================================
      // INSTRUCTIONS
      //
      // Backend uses "instruction"
      // Frontend uses "instructions"
      // =====================================================

      let instructions = "Not specified";

      if (
        typeof aiData.instruction === "string"
      ) {
        instructions = aiData.instruction;
      } else if (
        typeof aiData.instructions === "string"
      ) {
        instructions = aiData.instructions;
      } else if (
        aiData.instruction !== undefined &&
        aiData.instruction !== null
      ) {
        instructions = JSON.stringify(
          aiData.instruction
        );
      }

      // =====================================================
      // PRECAUTIONS
      //
      // Backend uses "precaution"
      // Frontend uses "precautions"
      // =====================================================

      let precautions = "Not specified";

      if (
        typeof aiData.precaution === "string"
      ) {
        precautions = aiData.precaution;
      } else if (
        typeof aiData.precautions === "string"
      ) {
        precautions = aiData.precautions;
      } else if (
        aiData.precaution !== undefined &&
        aiData.precaution !== null
      ) {
        precautions = JSON.stringify(
          aiData.precaution
        );
      }

      // =====================================================
      // SUMMARY
      // =====================================================

      let summary = "";

      if (
        typeof aiData.summary === "string"
      ) {
        summary = aiData.summary;
      }

      // =====================================================
      // NORMALIZED BRIEF
      // =====================================================

      const normalizedBrief = {
        medicines,
        duration,
        purpose,
        instructions,
        precautions,
        summary,

        // Keep original response for debugging
        raw: aiData,
      };

      console.log(
        "===================================="
      );

      console.log(
        "NORMALIZED AI BRIEF:"
      );

      console.log(
        normalizedBrief
      );

      console.log(
        "===================================="
      );

      // =====================================================
      // SAVE TO STATE
      // =====================================================

      setBriefs((previous) => ({
        ...previous,
        [prescriptionId]: normalizedBrief,
      }));
    } catch (err) {
      console.error(
        "===================================="
      );

      console.error(
        "AI BRIEF ERROR"
      );

      console.error(err);

      console.error(
        "===================================="
      );

      let errorMessage =
        "Unable to generate the prescription brief.";

      if (err.response) {
        console.error(
          "HTTP STATUS:",
          err.response.status
        );

        console.error(
          "BACKEND RESPONSE:",
          err.response.data
        );

        errorMessage =
          err.response.data?.error ||
          err.response.data?.message ||
          `AI server returned HTTP ${err.response.status}.`;
      } else if (err.request) {
        errorMessage =
          "The AI server did not respond. Check that Flask is running.";
      } else if (err.message) {
        errorMessage = err.message;
      }

      setBriefs((previous) => ({
        ...previous,
        [prescriptionId]: {
          error: errorMessage,
        },
      }));
    } finally {
      setBriefingIndex(null);
    }
  };

  // =========================================================
  // TTS TEXT
  // =========================================================

  const createSpeechText = (brief) => {
    if (!brief || brief.error) {
      return "";
    }

    const medicineText =
      brief.medicines
        ?.map(
          (medicine) =>
            `${medicine.name}. Dosage: ${medicine.dosage}. Frequency: ${medicine.frequency}.`
        )
        .join(" ") || "";

    return `
      Prescription brief.

      Medicines:
      ${medicineText}

      Duration:
      ${brief.duration}

      Purpose:
      ${brief.purpose}

      Instructions:
      ${brief.instructions}

      Precautions:
      ${brief.precautions}

      This is an AI generated summary.
      Please verify all medicine and dosage information
      with your doctor or pharmacist.
    `;
  };

  // =========================================================
  // READ AI BRIEF
  // =========================================================

  const readBrief = (brief) => {
    const text = createSpeechText(brief);

    if (!text) {
      return;
    }

    speak(text);
  };

  // =========================================================
  // DELETE PRESCRIPTION
  // =========================================================

  const deletePrescription = (id) => {
    stop();

    setPrescriptions((previous) =>
      previous.filter(
        (prescription) =>
          prescription.id !== id
      )
    );

    setBriefs((previous) => {
      const updated = {
        ...previous,
      };

      delete updated[id];

      return updated;
    });
  };

  // =========================================================
  // UI
  // =========================================================

  return (
    <div className="min-h-screen bg-slate-50">

      <PortalHeader />

      <main className="mx-auto max-w-5xl px-5 py-12">

        {/* =====================================================
            PAGE HEADER
        ===================================================== */}

        <p className="text-xs font-bold uppercase tracking-widest text-violet-500">
          PRESCRIPTIONS
        </p>

        <h1 className="mt-3 text-4xl font-black text-slate-900">
          Previous Prescriptions
        </h1>

        <p className="mt-3 text-slate-500">
          Upload and manage your previous
          prescriptions with AI-powered summaries.
        </p>

        {/* =====================================================
            UPLOAD CARD
        ===================================================== */}

        <div className="mt-8 rounded-3xl border-2 border-dashed border-slate-300 bg-white p-8">

          <div className="text-center">

            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-violet-50 text-3xl">
              📄
            </div>

            <h2 className="mt-5 text-xl font-black text-slate-900">
              Upload Prescription
            </h2>

            <p className="mt-2 text-sm text-slate-400">
              Upload PDF or DOCX prescription
            </p>

          </div>

          {/* ===================================================
              PATIENT ID
          =================================================== */}

          <div className="mx-auto mt-7 max-w-md">

            <label className="mb-2 block text-xs font-bold uppercase tracking-wide text-slate-400">
              Patient ID
            </label>

            <input
              type="text"
              value={patientId}
              onChange={(event) =>
                setPatientId(
                  event.target.value
                )
              }
              disabled={isUploading}
              placeholder="Enter patient ID"
              className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-900 outline-none transition focus:border-violet-400 focus:ring-2 focus:ring-violet-100 disabled:opacity-50"
            />

          </div>

          {/* ===================================================
              FILE INPUT
          =================================================== */}

          <div className="mx-auto mt-5 max-w-md">

            <label className="mb-2 block text-xs font-bold uppercase tracking-wide text-slate-400">
              Prescription Files
            </label>

            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept=".pdf,.docx"
              onChange={handleFileChange}
              disabled={isUploading}
              className="w-full text-sm text-slate-400 file:mr-3 file:cursor-pointer file:rounded-xl file:border-0 file:bg-violet-500 file:px-4 file:py-2 file:text-sm file:font-bold file:text-white hover:file:bg-violet-600"
            />

            <p className="mt-2 text-xs text-slate-400">
              Supported formats: PDF and DOCX
            </p>

          </div>

          {/* ===================================================
              SELECTED FILES
          =================================================== */}

          {selectedFiles.length > 0 && (
            <div className="mx-auto mt-5 max-w-md space-y-2">

              {selectedFiles.map(
                (file, index) => (
                  <div
                    key={`${file.name}-${index}`}
                    className="flex items-center justify-between rounded-xl border border-slate-200 bg-slate-50 px-4 py-3"
                  >

                    <div className="flex min-w-0 items-center gap-3">

                      <span className="text-lg">
                        📄
                      </span>

                      <span className="truncate text-sm font-semibold text-slate-700">
                        {file.name}
                      </span>

                    </div>

                    <button
                      type="button"
                      onClick={() =>
                        removeFile(index)
                      }
                      disabled={isUploading}
                      className="ml-3 text-slate-400 transition hover:text-red-500 disabled:opacity-50"
                    >
                      ✕
                    </button>

                  </div>
                )
              )}

            </div>
          )}

          {/* ===================================================
              UPLOAD BUTTON
          =================================================== */}

          <div className="mx-auto mt-6 max-w-md">

            <button
              type="button"
              onClick={handleUpload}
              disabled={isUploading}
              className="w-full rounded-xl bg-violet-500 py-3 font-bold text-white transition hover:bg-violet-600 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {isUploading
                ? `Transferring... ${progress}%`
                : "Upload Prescription"}
            </button>

          </div>

          {/* ===================================================
              PROGRESS
          =================================================== */}

          {isUploading && (
            <div className="mx-auto mt-6 max-w-md">

              <div className="mb-2 flex items-center justify-between">

                <span className="text-sm font-semibold text-slate-600">
                  Transferring files
                </span>

                <span className="text-sm font-black text-violet-600">
                  {progress}%
                </span>

              </div>

              <div
                className="h-3 w-full overflow-hidden rounded-full bg-slate-200"
                role="progressbar"
                aria-valuenow={progress}
                aria-valuemin="0"
                aria-valuemax="100"
              >

                <div
                  className="h-full rounded-full bg-violet-500 transition-[width] duration-200"
                  style={{
                    width: `${progress}%`,
                  }}
                />

              </div>

              <div className="mt-2 flex justify-between text-xs text-slate-400">

                <span>
                  {progress < 100
                    ? "Sending to MediBridge..."
                    : "File fully transferred"}
                </span>

                <span>
                  {progress}%
                </span>

              </div>

            </div>
          )}

          {/* ===================================================
              ERROR
          =================================================== */}

          {error && (
            <div className="mx-auto mt-5 max-w-md rounded-xl border border-red-100 bg-red-50 p-4">

              <p className="text-sm font-semibold text-red-500">
                {error}
              </p>

            </div>
          )}

          {/* ===================================================
              UPLOAD RESPONSE
          =================================================== */}

          {status && (
            <div className="mx-auto mt-5 max-w-md rounded-xl border border-slate-200 bg-slate-50 p-4">

              <div className="flex items-center gap-2">

                <span
                  className={`rounded px-2 py-1 text-xs font-bold ${
                    status.ok
                      ? "bg-emerald-100 text-emerald-600"
                      : "bg-red-100 text-red-600"
                  }`}
                >
                  {status.ok
                    ? "UPLOAD SUCCESS"
                    : "ERROR"}
                </span>

                <span className="text-xs text-slate-400">
                  HTTP {status.code}
                </span>

              </div>

              {response && (
                <pre className="mt-3 max-h-40 overflow-auto whitespace-pre-wrap rounded-lg bg-white p-3 text-xs text-slate-500">
                  {JSON.stringify(
                    response,
                    null,
                    2
                  )}
                </pre>
              )}

            </div>
          )}

        </div>

        {/* =====================================================
            PRESCRIPTION LIST
        ===================================================== */}

        <div className="mt-8 space-y-4">

          {prescriptions.length > 0 ? (

            prescriptions.map(
              (prescription) => {

                const brief =
                  briefs[prescription.id];

                const isGenerating =
                  briefingIndex ===
                  prescription.id;

                return (
                  <div
                    key={prescription.id}
                    className="rounded-3xl bg-white p-6 shadow-sm"
                  >

                    {/* =================================================
                        PRESCRIPTION HEADER
                    ================================================= */}

                    <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">

                      <div className="flex min-w-0 items-center gap-4">

                        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-violet-50 text-xl">
                          📄
                        </div>

                        <div className="min-w-0">

                          <p className="truncate font-bold text-slate-900">
                            {prescription.name}
                          </p>

                          <p className="mt-1 text-xs text-slate-400">
                            Uploaded on{" "}
                            {prescription.date}
                          </p>

                        </div>

                      </div>

                      <div className="flex shrink-0 gap-2">

                        <button
                          type="button"
                          onClick={() =>
                            generateBrief(
                              prescription
                            )
                          }
                          disabled={isGenerating}
                          className="rounded-xl bg-violet-500 px-4 py-2.5 text-sm font-bold text-white transition hover:bg-violet-600 disabled:cursor-not-allowed disabled:opacity-50"
                        >
                          {isGenerating
                            ? "⏳ Analyzing..."
                            : "✨ AI Brief"}
                        </button>

                        <button
                          type="button"
                          onClick={() =>
                            deletePrescription(
                              prescription.id
                            )
                          }
                          disabled={isGenerating}
                          className="rounded-xl bg-slate-100 px-4 py-2.5 text-sm font-bold text-slate-600 transition hover:bg-red-50 hover:text-red-500 disabled:opacity-50"
                        >
                          Delete
                        </button>

                      </div>

                    </div>

                    {/* =================================================
                        AI BRIEF
                    ================================================= */}

                    {brief && (
                      <div className="mt-6 rounded-3xl border border-violet-100 bg-violet-50 p-6">

                        {/* =============================================
                            ERROR
                        ============================================= */}

                        {brief.error ? (

                          <div>

                            <div className="flex items-center gap-3">

                              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-red-100">
                                ⚠️
                              </div>

                              <div>

                                <p className="font-black text-red-600">
                                  AI Brief Error
                                </p>

                                <p className="mt-1 text-xs text-red-400">
                                  The backend could not generate the brief.
                                </p>

                              </div>

                            </div>

                            <div className="mt-4 rounded-xl bg-white p-4">

                              <p className="text-sm leading-6 text-red-500">
                                {brief.error}
                              </p>

                            </div>

                            <button
                              type="button"
                              onClick={() =>
                                generateBrief(
                                  prescription
                                )
                              }
                              className="mt-4 rounded-xl bg-red-500 px-4 py-2 text-sm font-bold text-white transition hover:bg-red-600"
                            >
                              Try Again
                            </button>

                          </div>

                        ) : (

                          <>

                            {/* =========================================
                                AI HEADER
                            ========================================= */}

                            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">

                              <div className="flex items-center gap-3">

                                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white shadow-sm">
                                  ✨
                                </div>

                                <div>

                                  <p className="text-xs font-bold uppercase tracking-widest text-violet-500">
                                    AI ANALYSIS
                                  </p>

                                  <h3 className="font-black text-slate-900">
                                    Prescription Brief
                                  </h3>

                                </div>

                              </div>

                              {/* TTS */}

                              {!speaking ? (

                                <button
                                  type="button"
                                  onClick={() =>
                                    readBrief(
                                      brief
                                    )
                                  }
                                  disabled={ttsLoading}
                                  className="rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-bold text-white transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-50"
                                >
                                  {ttsLoading
                                    ? "⏳ Preparing Voice..."
                                    : "🔊 Read Brief"}
                                </button>

                              ) : (

                                <button
                                  type="button"
                                  onClick={stop}
                                  className="rounded-xl bg-red-500 px-4 py-2.5 text-sm font-bold text-white transition hover:bg-red-600"
                                >
                                  ⏹ Stop
                                </button>

                              )}

                            </div>

                            {/* =========================================
                                SUMMARY
                            ========================================= */}

                            {brief.summary && (
                              <div className="mt-6 rounded-2xl bg-white p-5">

                                <p className="text-xs font-bold uppercase tracking-widest text-violet-500">
                                  SUMMARY
                                </p>

                                <p className="mt-2 text-sm leading-6 text-slate-700">
                                  {brief.summary}
                                </p>

                              </div>
                            )}

                            {/* =========================================
                                MEDICINES
                            ========================================= */}

                            <div className="mt-6">

                              <p className="text-xs font-bold uppercase tracking-widest text-slate-400">
                                MEDICINES
                              </p>

                              <div className="mt-3 space-y-3">

                                {brief.medicines &&
                                brief.medicines.length > 0 ? (

                                  brief.medicines.map(
                                    (
                                      medicine,
                                      index
                                    ) => (

                                      <div
                                        key={index}
                                        className="rounded-2xl bg-white p-4"
                                      >

                                        <p className="font-black text-slate-900">
                                          {medicine.name}
                                        </p>

                                        <div className="mt-3 grid gap-3 sm:grid-cols-2">

                                          <div>

                                            <p className="text-xs text-slate-400">
                                              DOSAGE
                                            </p>

                                            <p className="mt-1 text-sm font-semibold text-slate-700">
                                              {medicine.dosage}
                                            </p>

                                          </div>

                                          <div>

                                            <p className="text-xs text-slate-400">
                                              FREQUENCY
                                            </p>

                                            <p className="mt-1 text-sm font-semibold text-slate-700">
                                              {medicine.frequency}
                                            </p>

                                          </div>

                                        </div>

                                      </div>

                                    )
                                  )

                                ) : (

                                  <div className="rounded-2xl bg-white p-4 text-sm text-slate-500">
                                    No medicine information was returned.
                                  </div>

                                )}

                              </div>

                            </div>

                            {/* =========================================
                                DURATION
                            ========================================= */}

                            <div className="mt-5 rounded-2xl bg-white p-5">

                              <p className="text-xs font-bold uppercase tracking-widest text-slate-400">
                                DURATION
                              </p>

                              <p className="mt-2 text-sm leading-6 text-slate-700">
                                {brief.duration}
                              </p>

                            </div>

                            {/* =========================================
                                PURPOSE
                            ========================================= */}

                            <div className="mt-5 rounded-2xl bg-white p-5">

                              <p className="text-xs font-bold uppercase tracking-widest text-slate-400">
                                PURPOSE
                              </p>

                              <p className="mt-2 text-sm leading-6 text-slate-700">
                                {brief.purpose}
                              </p>

                            </div>

                            {/* =========================================
                                INSTRUCTIONS
                            ========================================= */}

                            <div className="mt-5 rounded-2xl bg-white p-5">

                              <p className="text-xs font-bold uppercase tracking-widest text-slate-400">
                                INSTRUCTIONS
                              </p>

                              <p className="mt-2 text-sm leading-6 text-slate-700">
                                {brief.instructions}
                              </p>

                            </div>

                            {/* =========================================
                                PRECAUTIONS
                            ========================================= */}

                            <div className="mt-5 rounded-2xl border border-amber-100 bg-amber-50 p-5">

                              <p className="text-xs font-bold uppercase tracking-widest text-amber-600">
                                ⚠️ PRECAUTIONS
                              </p>

                              <p className="mt-2 text-sm leading-6 text-amber-800">
                                {brief.precautions}
                              </p>

                            </div>

                            {/* =========================================
                                DISCLAIMER
                            ========================================= */}

                            <p className="mt-5 text-xs leading-5 text-slate-400">
                              AI-generated summary for
                              convenience only. Always verify
                              medicine names, dosage, frequency,
                              and duration against the original
                              prescription.
                            </p>

                          </>

                        )}

                      </div>
                    )}

                  </div>
                );
              }
            )

          ) : (

            <EmptyState
              icon="📂"
              title="No prescriptions uploaded yet"
            />

          )}

        </div>

      </main>

    </div>
  );
}