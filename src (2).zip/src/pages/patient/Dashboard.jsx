import { Link } from "react-router-dom";
import PortalHeader from "../../components/PortalHeader";

export default function PatientDashboard() {
  const cards = [
    { to: "/patient/medicine-verification", icon: "💊", title: "Scan Medicine", text: "Upload a medicine image and extract medicine information." },
    { to: "/patient/book-appointment", icon: "🤖", title: "AI Appointment", text: "Describe symptoms, find a specialist and get rated doctors." },
    { to: "/patient/prescriptions", icon: "📄", title: "Prescriptions", text: "Upload and access your previous prescriptions." },
    { to: "/patient/appointments", icon: "📅", title: "My Appointments", text: "View and manage your booked appointments." },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      <PortalHeader />
      <main className="mx-auto max-w-7xl px-5 py-12 lg:px-8">
        <span className="rounded-full bg-teal-50 px-3 py-2 text-xs font-bold text-teal-600">PATIENT PORTAL</span>
        <h1 className="mt-5 text-4xl font-black md:text-5xl">Welcome to MediBridge</h1>
        <p className="mt-4 max-w-2xl text-slate-500">Manage medicines, appointments and prescriptions from one place.</p>

        <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {cards.map((card) => (
            <Link key={card.to} to={card.to} className="rounded-3xl border border-slate-200 bg-white p-7 shadow-sm transition hover:-translate-y-2 hover:border-teal-300 hover:shadow-xl">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-teal-50 text-2xl">{card.icon}</div>
              <h2 className="mt-6 text-xl font-black">{card.title}</h2>
              <p className="mt-3 text-sm leading-6 text-slate-500">{card.text}</p>
              <div className="mt-6 text-sm font-bold text-teal-500">Open →</div>
            </Link>
          ))}
        </div>
      </main>
    </div>
  );
}