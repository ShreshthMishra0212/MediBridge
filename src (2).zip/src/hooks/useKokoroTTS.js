import { useEffect, useRef, useState } from "react";
import { KokoroTTS } from "kokoro-js";

let kokoroInstance = null;
let kokoroLoadingPromise = null;

// Cache generated audio URLs
const audioCache = new Map();

async function getKokoro() {
  if (kokoroInstance) {
    return kokoroInstance;
  }

  if (!kokoroLoadingPromise) {
    kokoroLoadingPromise = KokoroTTS.from_pretrained(
      "onnx-community/Kokoro-82M-v1.0-ONNX",
      {
        dtype: "q8",
        device: "wasm",
      }
    );
  }

  try {
    kokoroInstance = await kokoroLoadingPromise;
    return kokoroInstance;
  } catch (error) {
    kokoroLoadingPromise = null;
    throw error;
  }
}

export default function useKokoroTTS() {
  const audioRef = useRef(null);

  const [loading, setLoading] = useState(false);
  const [speaking, setSpeaking] = useState(false);

  /*
   * Preload Kokoro when the hook is mounted.
   * This means the model can load while the user is
   * reading the medicine information.
   */
  useEffect(() => {
    getKokoro().catch((error) => {
      console.error("Kokoro preload failed:", error);
    });
  }, []);

  const stop = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      audioRef.current = null;
    }

    setSpeaking(false);
  };

  const speak = async (text) => {
    if (!text?.trim()) return;

    try {
      setLoading(true);

      stop();

      /*
       * Check whether this exact sentence has already
       * been generated.
       */
      let url = audioCache.get(text);

      if (!url) {
        const tts = await getKokoro();

        const audio = await tts.generate(text, {
          voice: "af_heart",
        });

        const blob = audio.toBlob();

        url = URL.createObjectURL(blob);

        audioCache.set(text, url);
      }

      const player = new Audio(url);

      audioRef.current = player;

      player.onplay = () => {
        setSpeaking(true);
      };

      player.onended = () => {
        setSpeaking(false);
        audioRef.current = null;
      };

      player.onerror = (error) => {
        console.error("TTS playback error:", error);

        setSpeaking(false);
        audioRef.current = null;
      };

      await player.play();
    } catch (error) {
      console.error("TTS generation error:", error);
      setSpeaking(false);
    } finally {
      setLoading(false);
    }
  };

  return {
    speak,
    stop,
    loading,
    speaking,
  };
}