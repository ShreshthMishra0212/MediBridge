import apiClient from "./axiosClient";

export const getDoctors = (params = {}) => apiClient.get("/doctors", { params });
export const getDoctor = (id) => apiClient.get(`/doctors/${id}`);
export const getDoctorRequests = () => apiClient.get("/doctor/requests");
export const getPatientDetails = (id) => apiClient.get(`/doctor/patients/${id}`);
