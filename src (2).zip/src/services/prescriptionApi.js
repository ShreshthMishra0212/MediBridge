import axios from "axios";

const BASE_URL = "http://192.168.9.23:5000";

/**
 * Uploads prescription files for a given patient.
 *
 * @param {string} patientId - e.g. "pa111"
 * @param {FileList | File[]} files - files from an <input type="file" multiple>
 * @param {(percent: number) => void} [onProgress] - optional upload progress callback
 * @returns {Promise<{status: number, data: any}>}
 */
export async function uploadPrescription(patientId, files, onProgress) {
  if (!patientId) throw new Error("patientId is required");
  if (!files || !files.length) throw new Error("At least one file is required");

  const formData = new FormData();
  for (const file of files) {
    formData.append("files", file);
  }

  // NOTE: no surrounding quotes around patientId in the query string.
  // Your original Python snippet used fname='{patient}', which sends
  // the literal characters 'pa111' (with quotes) to the server.
  const url = `${BASE_URL}/upload?fname=${encodeURIComponent(patientId)}`;

  try {
    const response = await axios.post(url, formData, {
      headers: {
        "Content-Type": "multipart/form-data",
        // Axios sets the correct multipart boundary automatically
        // when you pass a FormData instance — do not hardcode it.
      },
      onUploadProgress: (event) => {
        if (onProgress && event.total) {
          onProgress(Math.round((event.loaded * 100) / event.total));
        }
      },
    });

    return { status: response.status, data: response.data };
  } catch (error) {
    if (error.response) {
      // Server responded with a non-2xx status
      return { status: error.response.status, data: error.response.data };
    }
    // Network error, CORS block, timeout, etc.
    throw new Error(`Upload failed: ${error.message}`);
  }
}

// ---- Example usage (e.g. inside a submit handler) ----
//
// const fileInput = document.getElementById("files");
//
// uploadPrescription("pa111", fileInput.files, (pct) => {
//   console.log(`Upload progress: ${pct}%`);
// })
//   .then(({ status, data }) => {
//     console.log(status, data);
//   })
//   .catch((err) => {
//     console.error(err.message);
//   });