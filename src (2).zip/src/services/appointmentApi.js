import apiClient from "./axiosClient";

export const createAppointment = (payload) => apiClient.post("/appointments", payload);
export const getAppointments = () => apiClient.get("/appointments");
export const getAppointment = (id) => apiClient.get(`/appointments/${id}`);
export const cancelAppointment = (id) => apiClient.patch(`/appointments/${id}`, { status: "Cancelled" });
