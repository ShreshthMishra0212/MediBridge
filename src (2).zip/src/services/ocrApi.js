import apiClient from "./axiosClient";

export async function extractMedicine(imageFile) {
  const formData = new FormData();
  formData.append("image", imageFile);
  const response = await apiClient.post("/extract", formData, {
    headers: { "Content-Type": "multipart/form-data" },
  });
  return response.data;
}