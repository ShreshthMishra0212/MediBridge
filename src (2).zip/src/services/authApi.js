import apiClient from "./axiosClient";

export const login = (payload) => apiClient.post("/auth/login", payload);
export const register = (payload) => apiClient.post("/auth/register", payload);
