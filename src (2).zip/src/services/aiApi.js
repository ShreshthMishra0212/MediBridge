import apiClient from "./axiosClient";

export async function analyseSymptoms(symptoms) {
  const response = await apiClient.post("/ai/recommend-specialist", { symptoms });
  return response.data;
}