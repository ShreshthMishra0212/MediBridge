export function localSpecialistRecommendation(symptoms = "") {
  const text = symptoms.toLowerCase();
  if (["heart", "chest pain", "palpitation", "blood pressure"].some((x) => text.includes(x))) {
    return {
      specialist: "Cardiologist",
      advice: "Your symptoms may require evaluation of the heart and cardiovascular system. A Cardiologist may be appropriate."
    };
  }
  if (["skin", "rash", "acne", "itching"].some((x) => text.includes(x))) {
    return {
      specialist: "Dermatologist",
      advice: "Your symptoms appear related to the skin. A Dermatologist may be the appropriate specialist."
    };
  }
  if (["bone", "joint", "fracture", "back pain"].some((x) => text.includes(x))) {
    return {
      specialist: "Orthopedic",
      advice: "Your symptoms may involve bones, joints or muscles. An Orthopedic specialist may be appropriate."
    };
  }
  if (["ear", "nose", "throat", "hearing"].some((x) => text.includes(x))) {
    return {
      specialist: "ENT Specialist",
      advice: "Your symptoms appear related to the ear, nose or throat. An ENT Specialist may be appropriate."
    };
  }
  if (["pregnancy", "period", "menstrual", "pregnant"].some((x) => text.includes(x))) {
    return {
      specialist: "Gynecologist",
      advice: "For reproductive, menstrual or pregnancy-related concerns, a Gynecologist may be appropriate."
    };
  }
  return {
    specialist: "General Physician",
    advice: "Based on the information provided, starting with a General Physician may be appropriate."
  };
}