export const doctors = [
  { id: 1, name: "Dr. Ankit Sharma", specialist: "General Physician", area: "Noida", rating: 4.9, experience: "12 Years", fee: "₹500" },
  { id: 2, name: "Dr. Priya Mehta", specialist: "Cardiologist", area: "Noida", rating: 4.8, experience: "15 Years", fee: "₹1000" },
  { id: 3, name: "Dr. Rahul Verma", specialist: "Dermatologist", area: "Noida", rating: 4.7, experience: "10 Years", fee: "₹700" },
  { id: 4, name: "Dr. Neha Gupta", specialist: "General Physician", area: "Delhi", rating: 4.9, experience: "14 Years", fee: "₹600" },
  { id: 5, name: "Dr. Arjun Kapoor", specialist: "Orthopedic", area: "Delhi", rating: 4.8, experience: "16 Years", fee: "₹900" },
  { id: 6, name: "Dr. Simran Kaur", specialist: "Gynecologist", area: "Ghaziabad", rating: 4.9, experience: "13 Years", fee: "₹800" },
  { id: 7, name: "Dr. Mohit Singh", specialist: "ENT Specialist", area: "Ghaziabad", rating: 4.6, experience: "9 Years", fee: "₹600" }
];

export const specialists = ["General Physician", "Cardiologist", "Dermatologist", "Orthopedic", "ENT Specialist", "Gynecologist"];
export const areas = ["Noida", "Delhi", "Ghaziabad"];
