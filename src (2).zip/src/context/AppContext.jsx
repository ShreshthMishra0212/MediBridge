import { createContext, useContext, useEffect, useState } from "react";

const AppContext = createContext(null);

const API_BASE = "http://127.0.0.1:5000";

export function AppProvider({ children }) {
  const [currentUser, setCurrentUser] = useState({
    id: 1,
    name: "Demo Patient",
    role: "patient",
  });

  const [appointments, setAppointments] = useState([]);

  const [loadingAppointments, setLoadingAppointments] = useState(false);

  // =====================================================
  // GET TOKEN
  // =====================================================

  const getToken = () => {
    return (
      localStorage.getItem("token") ||
      sessionStorage.getItem("token")
    );
  };

  // =====================================================
  // FETCH PATIENT APPOINTMENTS
  // =====================================================

  const fetchAppointments = async () => {
    const token = getToken();

    if (!token) {
      return;
    }

    try {
      setLoadingAppointments(true);

      const response = await fetch(
        `${API_BASE}/api/patients/appointments`,
        {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (!response.ok) {
        throw new Error("Failed to fetch appointments");
      }

      const data = await response.json();

      setAppointments(data.appointments || []);
    } catch (error) {
      console.error("Error fetching appointments:", error);
    } finally {
      setLoadingAppointments(false);
    }
  };

  // =====================================================
  // FETCH APPOINTMENTS WHEN USER IS PATIENT
  // =====================================================

  useEffect(() => {
    if (currentUser?.role === "patient") {
      fetchAppointments();
    }
  }, [currentUser]);

  // =====================================================
  // ADD APPOINTMENT
  // =====================================================

  const addAppointment = async (appointment) => {
    const token = getToken();

    // If backend token isn't available,
    // keep old frontend behaviour so existing UI doesn't crash.
    if (!token) {
      const localAppointment = {
        id: Date.now(),
        ...appointment,
      };

      setAppointments((prev) => [
        localAppointment,
        ...prev,
      ]);

      return localAppointment;
    }

    try {
      const response = await fetch(
        `${API_BASE}/api/patients/appointments`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            doctor_id:
              appointment.doctor_id ||
              appointment.doctorId,

            date: appointment.date,
            time: appointment.time,
          }),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.error || "Failed to create appointment"
        );
      }

      // Add the actual backend appointment
      setAppointments((prev) => [
        data.appointment,
        ...prev,
      ]);

      return data.appointment;

    } catch (error) {
      console.error("Error creating appointment:", error);

      alert(
        error.message ||
          "Could not create appointment."
      );

      return null;
    }
  };

  // =====================================================
  // UPDATE APPOINTMENT
  // =====================================================

  const updateAppointment = async (id, patch) => {
    const token = getToken();

    /*
      Keep local update behaviour for things that are
      currently frontend-only, such as cancellation.
    */

    // ---------------------------------------------------
    // PATIENT ACCEPTS DOCTOR'S SUGGESTED TIME
    // ---------------------------------------------------

    if (
      patch.status === "Confirmed" &&
      token
    ) {
      try {
        const response = await fetch(
          `${API_BASE}/api/patients/appointments/${id}/accept`,
          {
            method: "PUT",
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );

        const data = await response.json();

        if (!response.ok) {
          throw new Error(
            data.error ||
              "Failed to accept appointment"
          );
        }

        setAppointments((prev) =>
          prev.map((item) =>
            String(item.id) === String(id)
              ? data.appointment
              : item
          )
        );

        return data.appointment;

      } catch (error) {
        console.error(
          "Error accepting appointment:",
          error
        );

        alert(
          error.message ||
            "Could not accept appointment."
        );

        return null;
      }
    }

    // ---------------------------------------------------
    // PATIENT REJECTS DOCTOR'S SUGGESTION
    // ---------------------------------------------------

    if (
      patch.status === "Cancelled" &&
      token
    ) {
      try {
        const response = await fetch(
          `${API_BASE}/api/patients/appointments/${id}/reject`,
          {
            method: "PUT",
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );

        const data = await response.json();

        if (!response.ok) {
          throw new Error(
            data.error ||
              "Failed to reject appointment"
          );
        }

        setAppointments((prev) =>
          prev.map((item) =>
            String(item.id) === String(id)
              ? data.appointment
              : item
          )
        );

        return data.appointment;

      } catch (error) {
        console.error(
          "Error rejecting appointment:",
          error
        );

        alert(
          error.message ||
            "Could not reject appointment."
        );

        return null;
      }
    }

    // ---------------------------------------------------
    // FALLBACK / EXISTING FRONTEND BEHAVIOUR
    // ---------------------------------------------------

    setAppointments((prev) =>
      prev.map((item) =>
        String(item.id) === String(id)
          ? { ...item, ...patch }
          : item
      )
    );
  };

  // =====================================================
  // CONTEXT
  // =====================================================

  return (
    <AppContext.Provider
      value={{
        currentUser,
        setCurrentUser,

        appointments,
        setAppointments,

        addAppointment,
        updateAppointment,

        fetchAppointments,
        loadingAppointments,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const value = useContext(AppContext);

  if (!value) {
    throw new Error(
      "useApp must be used inside AppProvider"
    );
  }

  return value;
}