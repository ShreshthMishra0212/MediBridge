import {
  BrowserRouter,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";

import "./index.css";

// Public pages
import Login from "./pages/login";
import Register from "./pages/register";

// Patient pages
import PatientDashboard from "./pages/patient/Dashboard";
import BookAppointment from "./pages/patient/BookAppointment";
import DoctorList from "./pages/patient/DoctorList";
import DoctorProfile from "./pages/patient/DoctorProfile";
import PatientAppointmentDetails from "./pages/patient/AppointmentDetails";
import MyAppointments from "./pages/patient/MyAppointments";
import PatientPrescription from "./pages/patient/Prescription";
import MedicineVerification from "./pages/patient/MedicineVerification";

// Doctor pages
import DoctorDashboard from "./pages/doctor/Dashboard";
import DoctorProfilePage from "./pages/doctor/Profile";
import PatientRequests from "./pages/doctor/PatientRequests";
import PatientDetails from "./pages/doctor/PatientDetails";
import DoctorAppointmentDetails from "./pages/doctor/AppointmentDetails";
import DoctorPrescription from "./pages/doctor/Prescription";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>

        {/* =========================
            PUBLIC ROUTES
        ========================= */}

        <Route
          path="/"
          element={<Navigate to="/login" replace />}
        />

        <Route
          path="/login"
          element={<Login />}
        />

        <Route
          path="/register"
          element={<Register />}
        />


        {/* =========================
            PATIENT ROUTES
        ========================= */}

        <Route
          path="/patient"
          element={<PatientDashboard />}
        />

        <Route
          path="/patient/dashboard"
          element={<PatientDashboard />}
        />

        <Route
          path="/patient/book-appointment"
          element={<BookAppointment />}
        />

        <Route
          path="/patient/doctors"
          element={<DoctorList />}
        />

        <Route
          path="/patient/doctors/:doctorId"
          element={<DoctorProfile />}
        />

        <Route
          path="/patient/appointments/:appointmentId"
          element={<PatientAppointmentDetails />}
        />

        <Route
          path="/patient/appointments"
          element={<MyAppointments />}
        />

        <Route
          path="/patient/prescriptions"
          element={<PatientPrescription />}
        />

        <Route
          path="/patient/medicine-verification"
          element={<MedicineVerification />}
        />


        {/* =========================
            BACKWARD COMPATIBLE
            PATIENT ROUTES
        ========================= */}

        <Route
          path="/appointment"
          element={<BookAppointment />}
        />

        <Route
          path="/medicine-analysis"
          element={<MedicineVerification />}
        />

        <Route
          path="/prescriptions"
          element={<PatientPrescription />}
        />


        {/* =========================
            DOCTOR ROUTES
        ========================= */}

        <Route
          path="/doctor"
          element={<DoctorDashboard />}
        />

        <Route
          path="/doctor/dashboard"
          element={<DoctorDashboard />}
        />

        <Route
          path="/doctor/profile"
          element={<DoctorProfilePage />}
        />

        <Route
          path="/doctor/requests"
          element={<PatientRequests />}
        />

        <Route
          path="/doctor/patients/:patientId"
          element={<PatientDetails />}
        />

        <Route
          path="/doctor/appointments/:appointmentId"
          element={<DoctorAppointmentDetails />}
        />

        <Route
          path="/doctor/prescriptions"
          element={<DoctorPrescription />}
        />


        {/* =========================
            UNKNOWN ROUTES
        ========================= */}

        <Route
          path="*"
          element={<Navigate to="/login" replace />}
        />

      </Routes>
    </BrowserRouter>
  );
}