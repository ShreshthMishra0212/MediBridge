import { Link } from "react-router-dom";
import logo from "/src/assets/logo.jpeg";
export default function Logo() {
  return (
    <Link to="/" className="flex items-center gap-3">
     <div className="flex h-12 w-12 items-center justify-center rounded-xl overflow-hidden shadow-lg">
  <img
    src={logo}
    alt="MediBridge logo"
    className="h-full w-full object-cover"
  />
</div>
      <div>
        <div className="text-xl font-black tracking-tight">
          Medi<span className="text-teal-500">Bridge</span>
        </div>
        <p className="hidden text-[9px] font-bold uppercase tracking-[0.2em] text-slate-400 sm:block">
          Intelligent Care, Human Touch
        </p>
      </div>
    </Link>
  );
}