import { Link } from "react-router-dom";
import Logo from "./Logo";

export default function PortalHeader({ role = "patient" }) {
  const base = role === "doctor" ? "/doctor" : "/patient";
  return (
    <header className="sticky top-0 z-50 border-b border-slate-200 bg-white/90 backdrop-blur-xl">
      <div className="mx-auto flex min-h-[76px] max-w-7xl items-center justify-between gap-4 px-5 lg:px-8">
        <Logo />
        <nav className="hidden gap-5 md:flex">
          <Link to={base} className="text-sm font-bold text-slate-600 hover:text-teal-600">Dashboard</Link>
          {role === "patient" ? (
            <>
              <Link to="/patient/book-appointment" className="text-sm font-bold text-slate-600 hover:text-teal-600">Book</Link>
              <Link to="/patient/appointments" className="text-sm font-bold text-slate-600 hover:text-teal-600">Appointments</Link>
              <Link to="/patient/prescriptions" className="text-sm font-bold text-slate-600 hover:text-teal-600">Prescriptions</Link>
            </>
          ) : (
            <>
              <Link to="/doctor/requests" className="text-sm font-bold text-slate-600 hover:text-teal-600">Requests</Link>
              <Link to="/doctor/profile" className="text-sm font-bold text-slate-600 hover:text-teal-600">Profile</Link>
            </>
          )}
        </nav>
        <Link to="/" className="rounded-xl bg-slate-100 px-4 py-2 text-sm font-bold text-slate-600 hover:bg-slate-200">
          ← Home
        </Link>
      </div>
    </header>
  );
}