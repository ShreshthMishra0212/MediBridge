export default function StatusBadge({ status = "Pending" }) {
  const styles = {
    Pending: "bg-amber-50 text-amber-700",
    Confirmed: "bg-emerald-50 text-emerald-700",
    Completed: "bg-blue-50 text-blue-700",
    Cancelled: "bg-red-50 text-red-700",
  };
  return <span className={`rounded-full px-3 py-1 text-xs font-bold ${styles[status] || "bg-slate-100 text-slate-600"}`}>{status}</span>;
}