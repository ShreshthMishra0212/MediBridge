import { useState } from "react";
import { Link } from "react-router-dom";
import Logo from "./Logo";

export default function Navbar() {
  const [showAbout, setShowAbout] = useState(false);

  return (
    <>
      {/* Sticky Navbar */}
      <header className="fixed top-0 left-0 z-50 w-full border-b border-slate-200/70 bg-white/90 backdrop-blur-xl">
        <div className="mx-auto flex h-[76px] max-w-7xl items-center justify-between px-5 lg:px-8">

          <Logo />

          <nav className="hidden items-center gap-8 md:flex">
            <button
              onClick={() => setShowAbout(true)}
              className="text-sm font-semibold text-slate-600 hover:text-teal-500"
            >
              About
            </button>

            <Link
              to="/patient"
              className="text-sm font-semibold text-slate-600 hover:text-teal-500"
            >
              Patient
            </Link>

            <Link
              to="/doctor"
              className="text-sm font-semibold text-slate-600 hover:text-teal-500"
            >
              Doctor
            </Link>
          </nav>

          <div className="hidden items-center gap-2 rounded-full border border-emerald-100 bg-emerald-50 px-4 py-2 sm:flex">
            <span className="h-2 w-2 animate-pulse rounded-full bg-emerald-500" />
            <span className="text-xs font-bold text-emerald-700">
              Platform Online
            </span>
          </div>
        </div>
      </header>

      {/* About Modal */}
      {showAbout && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/60 px-5 backdrop-blur-sm"
          onClick={() => setShowAbout(false)}
        >
          <div
            className="w-full max-w-lg rounded-[28px] bg-white p-7 shadow-2xl md:p-9"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between">
              <Logo />

              <button
                onClick={() => setShowAbout(false)}
                className="flex h-9 w-9 items-center justify-center rounded-full bg-slate-100 text-slate-500"
              >
                ✕
              </button>
            </div>

            <div className="mt-7">
              <h2 className="text-2xl font-black">
                Bridging healthcare through technology.
              </h2>

              <p className="mt-4 text-sm leading-7 text-slate-500">
                MediBridge connects patients and doctors by making medicine
                information easier to extract, understand and organize.
              </p>

              <div className="mt-6 space-y-3">
                <Info
                  icon="📷"
                  title="Medicine Recognition"
                  text="Extract medicine information from images using OCR."
                />

                <Info
                  icon="🤖"
                  title="AI Appointment Assistant"
                  text="Get general guidance about which specialist may be appropriate."
                />

                <Info
                  icon="🩺"
                  title="Doctor Recommendations"
                  text="Find highly rated doctors based on specialist and area."
                />
              </div>
            </div>

            <button
              onClick={() => setShowAbout(false)}
              className="mt-7 w-full rounded-xl bg-slate-900 py-3.5 text-sm font-bold text-white hover:bg-teal-600"
            >
              Continue to MediBridge
            </button>
          </div>
        </div>
      )}
    </>
  );
}

function Info({ icon, title, text }) {
  return (
    <div className="rounded-2xl bg-slate-50 p-4">
      <p className="font-bold">
        {icon} {title}
      </p>

      <p className="mt-1 text-xs text-slate-400">
        {text}
      </p>
    </div>
  );
}