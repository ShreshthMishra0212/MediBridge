export default function FeatureCard({ icon, title, text }) {
  return (
    <div className="group rounded-3xl border border-slate-200 bg-slate-50 p-7 transition hover:-translate-y-2 hover:border-teal-200 hover:bg-white hover:shadow-xl">
      <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-teal-100 text-2xl group-hover:scale-110">
        {icon}
      </div>
      <h3 className="mt-6 text-lg font-black">{title}</h3>
      <p className="mt-3 text-sm leading-6 text-slate-500">{text}</p>
    </div>
  );
}