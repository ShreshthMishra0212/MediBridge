export default function EmptyState({ icon = "📂", title, text }) {
  return (
    <div className="rounded-3xl border border-slate-200 bg-white p-10 text-center">
      <p className="text-4xl">{icon}</p>
      <p className="mt-3 font-bold text-slate-700">{title}</p>
      {text && <p className="mt-1 text-sm text-slate-400">{text}</p>}
    </div>
  );
}