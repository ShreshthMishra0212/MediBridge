import { Link } from "react-router-dom";

export default function DoctorCard({ doctor, selected, onSelect }) {
  return (
    <div className={`rounded-3xl border bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-xl ${selected ? "border-teal-400 ring-2 ring-teal-100" : "border-slate-200"}`}>
      <div className="flex items-start justify-between gap-4">
        <div className="flex gap-4">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-blue-50 text-2xl">🩺</div>
          <div>
            <h3 className="font-black">{doctor.name}</h3>
            <p className="mt-1 text-sm text-teal-600">{doctor.specialist}</p>
          </div>
        </div>
        <div className="rounded-xl bg-amber-50 px-3 py-2 text-center">
          <p className="text-sm font-black text-amber-600">⭐ {doctor.rating}</p>
          <p className="text-[9px] text-slate-400">Rating</p>
        </div>
      </div>
      <div className="mt-5 grid grid-cols-3 gap-3">
        <Stat label="AREA" value={doctor.area} />
        <Stat label="EXPERIENCE" value={doctor.experience} />
        <Stat label="FEE" value={doctor.fee} />
      </div>
      <div className="mt-5 flex gap-3">
        <button onClick={() => onSelect?.(doctor)} className={`flex-1 rounded-xl py-3 text-sm font-bold ${selected ? "bg-teal-500 text-white" : "bg-slate-900 text-white hover:bg-teal-600"}`}>
          {selected ? "✓ Selected" : "Select Doctor"}
        </button>
        <Link to={`/patient/doctors/${doctor.id}`} className="rounded-xl border border-slate-200 px-4 py-3 text-sm font-bold text-slate-600 hover:border-teal-300">
          Profile
        </Link>
      </div>
    </div>
  );
}

function Stat({ label, value }) {
  return (
    <div className="rounded-xl bg-slate-50 p-3">
      <p className="text-[9px] text-slate-400">{label}</p>
      <p className="mt-1 text-xs font-bold">{value}</p>
    </div>
  );
}