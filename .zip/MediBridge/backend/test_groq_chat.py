import requests

GROQ_API_KEY = "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"

# Try standard Groq chat completions
urls_to_try = [
    "https://api.groq.com/openai/v1/chat/completions",
]

for url in urls_to_try:
    print(f"\nTrying: {url}")
    resp = requests.post(
        url,
        headers={
            "Authorization": f"Bearer {GROQ_API_KEY}",
            "Content-Type": "application/json"
        },
        json={
            "model": "qwen/qwen3.8-27b",
            "messages": [{"role": "user", "content": "Say hello in one word."}],
            "max_tokens": 10,
            "stream": False
        },
        timeout=30
    )
    print(f"Status: {resp.status_code}")
    if resp.status_code == 200:
        print("Response:", resp.json()["choices"][0]["message"]["content"])
    else:
        print("Error body:", resp.text[:500])
