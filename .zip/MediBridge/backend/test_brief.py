import sys
sys.path.insert(0, 'routes')
from briefer import summarize_health_report

patient_id = '3576a68d-baa6-43ad-b614-fa3df593b1c7'
print(f"Testing brief for patient: {patient_id}")

r = summarize_health_report(patient_id=patient_id)

print("--- RESULT ---")
print("SUMMARY:", r['summary'][:150])
print("MEDICINES:", r['medicines'][:120])
print("DURATION:", r['duration'][:100])
print("HINDI SUMMARY:", r['languages']['hindi']['summary'][:120])
print("--- TEST PASSED ---")
