import requests

GROQ_API_KEY = "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"

# List available models
resp = requests.get(
    "https://api.groq.com/openai/v1/models",
    headers={"Authorization": f"Bearer {GROQ_API_KEY}"}
)
print("Status:", resp.status_code)
if resp.status_code == 200:
    models = resp.json()["data"]
    print("Available models:")
    for m in sorted(models, key=lambda x: x["id"]):
        print(" -", m["id"])
else:
    print("Error:", resp.text)
